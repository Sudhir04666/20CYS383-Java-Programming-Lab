package com.amrita.jpl.cys21074.p2;

public class quizclient {
    public static void main(String[] args) {
        QuizGameClient client = new QuizGameClient();
        client.startGame();
    }
}
