package com.amrita.jpl.cys21074.ex;

import java.util.Scanner;

class Vehicle{
    Scanner scanner = new Scanner(System.in);
    double run_status;
    public void start(){
        run_status=1;
    }
    public void stop(){
        run_status=0;
    }
}

class car extends Vehicle{
    public car(){
        String model = scanner.next();
        double year = scanner.nextDouble();
        double numwheels = scanner.nextDouble();
    }
}
class bike extends Vehicle{

}
public class vehicle_inheritance {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}


